import java.util.*;

public class Perceptron {

    double[] wags;
    double prog;
    double parametr_a;
    Map<String, List<List<Float>>> testMap = null;
    Map<String, List<List<Float>>> trainMap = null;
    double howLong;
    String[] grups;

    public Perceptron(double parametr_a, int rozmiarWektora) {
        this.wags = new double[rozmiarWektora];
        Random r = new Random();

        for (int i = 0; i < wags.length ; i++) {
            wags[i] = r.nextDouble()*5-5;
        }
        this.prog = r.nextDouble()*5-5;
        this.parametr_a = parametr_a;
    }

    public void trainPerceptron(Map<String, List<List<Float>>> trainMap, boolean testAgain){
        this.trainMap = trainMap;
        this.grups = trainMap.keySet().toArray(new String[0]);
        for (String x: grups) {
            for (int i = 0; i < trainMap.get(x).size(); i++) {
                double sum = 0;
                List<Float> list = new ArrayList<>();
                for (int j = 0; j < trainMap.get(x).get(i).size(); j++) {
                    sum += trainMap.get(x).get(i).get(j)*wags[j];
                    list.add(trainMap.get(x).get(i).get(j));
                    if (j == trainMap.get(x).get(i).size()-1){
                        int y;
                        if (sum >= prog){
                            y = 1;
                        }else {
                            y = 0;
                        }

                        int d;
                        if (!grups[y].equals(x)){
                           if (y == 1){
                               d = 0;
                           }else{
                               d = 1;
                           }

                            for (int k = 0; k < wags.length; k++) {
                                wags[k] = wags[k] + (d-y)*parametr_a * list.get(k);
                            }
                            prog = prog-(d-y)*parametr_a;
                        }
                    }
                }
            }
        }
        if (testAgain){
            testPerceptron(this.testMap, false, this.howLong);
        }
    }

    public void testPerceptron(Map<String, List<List<Float>>> testMap, boolean print, double howLong){
        this.testMap = testMap;
        this.howLong = howLong;

        int all = 0;
        int ok = 0;
        int all01 = 0;
        int ok01 = 0;
        int all02 = 0;
        int ok02 = 0;
        for (String x:grups) {
            for (int i = 0; i < testMap.get(x).size(); i++) {
                double sum = 0;
                List<Float> list = new ArrayList<>();
                all++;
                if (x.equals(grups[0])){
                    all01++;
                }else{
                    all02++;
                }
                for (int j = 0; j < testMap.get(x).get(i).size(); j++) {
                    sum += testMap.get(x).get(i).get(j)*wags[j];
                    list.add(testMap.get(x).get(i).get(j));
                    if (j == testMap.get(x).get(i).size()-1){
                        int y;
                        if (sum-prog >= 0){
                            y = 1;
                        }else {
                            y = 0;
                        }

                        if (grups[y].equals(x)) {
                            ok++;
                            if (x.equals(grups[0])){
                                ok01++;
                            }else{
                                ok02++;
                            }
                        }
                    }
                }
            }
        }

        if (!print){
            if ((double) ok/all < howLong){
                trainPerceptron(trainMap, true);
            }else{
                testPerceptron(this.testMap, true, howLong);
            }
        }else{
            System.out.println("For all grups --> " + (double)ok/all);
            System.out.println(grups[0] +" --> " + (double)ok01/all01);
            System.out.println(grups[1] +" --> " + (double)ok02/all02);
        }
    }

    public void whatGrup(String str){
        List<Float> list = new ArrayList<>();
        String[] strT = str.split(";");
        for (String s: strT) {
            list.add(Float.parseFloat(s));
        }

        double sum = 0;
        for (int i = 0; i < list.size() ; i++) {
            sum += list.get(i)*wags[i];
        }
        if (sum - prog >= 0 ){
            System.out.println(this.grups[1]);
        }else{
            System.out.println(this.grups[0]);
        }
    }
}
